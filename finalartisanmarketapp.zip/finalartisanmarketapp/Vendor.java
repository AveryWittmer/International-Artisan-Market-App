package com.example.finalartisanmarketapp;

import android.net.Uri;

import com.google.firebase.storage.StorageReference;

import java.net.URL;

public class Vendor {
    String vendorName;
    String vendorSiteUrl;
    String vendorLogoUrl;
}
